
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-demo]").forEach(btn => {
    btn.addEventListener("click", () => {
      const out = document.querySelector(btn.dataset.demo);
      if (out) {
        out.hidden = false;
        out.textContent = "Preview mode: this GitHub Pages build is a static UI. Connect your own compliant backend/API separately.";
      }
    });
  });
});
