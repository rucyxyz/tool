# Discord Tools — GitHub Pages UI

画像を参考にしたダーク系の静的ダッシュボードです。

## 構成

- `index.html` — ダッシュボード
- `assets/css/style.css` — 共通スタイル
- `assets/js/app.js` — UI用JavaScript
- `tools/*.html` — 各ツールを独立したHTMLとして配置

## GitHub Pages

GitHub Pages は静的ファイルを公開する用途なので、HTML/CSS/JavaScriptのフロントエンドをそのまま配置できます。

1. このフォルダの中身をGitHubリポジトリへpush
2. Settings → Pages
3. Sourceを `Deploy from a branch`
4. `main` / `/ (root)` を選択
5. Save

`.nojekyll` も同梱しています。

## 注意

この版はUI/ページ構成のみです。Discordのスパム、raid、トークン操作、認証情報の収集・検証などを実行するバックエンドは実装していません。
